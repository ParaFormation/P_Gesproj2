<?php
session_start();
/**
 * Author: carvalhoda
 * Date: 29.02.2016
 * Summary: 
 */
include "gesprojClass.php";
$logout=new gesprojClass();
$logout->Logout();
?>
